/** Automatically generated file. DO NOT MODIFY */
package code.example.storyandroid;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}